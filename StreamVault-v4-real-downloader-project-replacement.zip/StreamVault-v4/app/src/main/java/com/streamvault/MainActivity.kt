package com.streamvault

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.view.View
import android.widget.*
import android.text.TextUtils
import dev.ffmpegkit_maintained.ytdlp.YtDlp
import dev.ffmpegkit_maintained.ytdlp.YtDlpRequest
import dev.ffmpegkit_maintained.ytdlp.YtDlpResponse
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {
    private lateinit var urlInput: EditText
    private lateinit var qualitySpinner: Spinner
    private lateinit var statusText: TextView
    private lateinit var downloadsList: LinearLayout
    private lateinit var downloadButton: Button
    private val running = AtomicBoolean(false)
    private var downloaderReady = false
    private val formats = listOf(
        "Best available",
        "1080p",
        "720p",
        "480p",
        "360p",
        "Audio only"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            YtDlp.init(applicationContext)
            downloaderReady = true
        } catch (e: Exception) {
            Toast.makeText(this, "Downloader initialization failed: ${e.message}", Toast.LENGTH_LONG).show()
        }

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
        }
        val scroll = ScrollView(this)
        scroll.addView(page)

        page.addView(TextView(this).apply {
            text = "StreamVault"
            textSize = 30f
            setTypeface(null, Typeface.BOLD)
        })
        page.addView(TextView(this).apply {
            text = "Rumble + KICK video downloader"
            textSize = 15f
            setPadding(0, 4, 0, 20)
        })

        urlInput = EditText(this).apply {
            hint = "Paste a Rumble or KICK URL"
            setSingleLine(true)
            textSize = 14f
        }
        page.addView(urlInput, LinearLayout.LayoutParams(-1, -2))

        page.addView(TextView(this).apply {
            text = "Video quality"
            textSize = 14f
            setPadding(0, 16, 0, 4)
        })
        qualitySpinner = Spinner(this)
        qualitySpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, formats
        )
        page.addView(qualitySpinner)

        downloadButton = Button(this).apply {
            text = "Download"
            setOnClickListener { startDownload() }
        }
        page.addView(downloadButton, LinearLayout.LayoutParams(-1, -2))

        statusText = TextView(this).apply {
            text = "Paste a public VOD URL to begin."
            textSize = 14f
            setPadding(0, 12, 0, 18)
        }
        page.addView(statusText)

        page.addView(TextView(this).apply {
            text = "Recent downloads"
            textSize = 21f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 8, 0, 8)
        })
        downloadsList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(downloadsList)

        setContentView(scroll)
        acceptSharedUrl(intent)
        listExistingDownloads()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        acceptSharedUrl(intent)
    }

    private fun acceptSharedUrl(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            intent.getStringExtra(Intent.EXTRA_TEXT)?.let { urlInput.setText(it) }
        }
    }

    private fun validPlatformUrl(value: String): Boolean {
        val uri = try { Uri.parse(value) } catch (_: Exception) { return false }
        val host = (uri.host ?: "").lowercase()
        return uri.scheme in listOf("http", "https") &&
            (host == "rumble.com" || host.endsWith(".rumble.com") ||
             host == "kick.com" || host.endsWith(".kick.com"))
    }

    private fun formatSelector(choice: String): String = when (choice) {
        "1080p" -> "bv*[height<=1080]+ba/b[height<=1080]"
        "720p" -> "bv*[height<=720]+ba/b[height<=720]"
        "480p" -> "bv*[height<=480]+ba/b[height<=480]"
        "360p" -> "bv*[height<=360]+ba/b[height<=360]"
        "Audio only" -> "bestaudio/best"
        else -> "bv*+ba/b"
    }

    private fun downloadsDir(): File {
        return File(getExternalFilesDir(null), "StreamVault").apply { mkdirs() }
    }

    private fun startDownload() {
        if (!downloaderReady) {
            statusText.text = "Downloader could not initialize. Close and reopen the app."
            return
        }
        val url = urlInput.text.toString().trim()
        if (!validPlatformUrl(url)) {
            statusText.text = "Please paste a valid Rumble or KICK URL."
            return
        }
        if (!running.compareAndSet(false, true)) {
            statusText.text = "A download is already running. Wait for it to finish before starting another."
            return
        }

        downloadButton.isEnabled = false
        val choice = qualitySpinner.selectedItem.toString()
        val item = makeDownloadRow(url, choice)
        val progress = item.first
        val label = item.second
        statusText.text = "Preparing download…"

        Thread {
            try {
                val output = File(downloadsDir(), "%(title).180B [%(id)s].%(ext)s").absolutePath
                val request = YtDlpRequest(url)
                    .setOutputTemplate(output)
                    .addOption("-f", formatSelector(choice))
                    .addOption("--no-playlist")
                    .addOption("--newline")
                if (choice != "Audio only") {
                    request.addOption("--merge-output-format", "mp4")
                }

                val future = YtDlp.executeAsync(request) { percent, eta, line ->
                    runOnUiThread {
                        if (percent >= 0) progress.progress = percent.toInt().coerceIn(0, 100)
                        label.text = when {
                            percent >= 0 -> "${percent.toInt()}% • ETA ${eta}s\\n${line.take(220)}"
                            else -> line.take(260)
                        }
                        statusText.text = if (percent >= 0) "Downloading… ${percent.toInt()}%" else line.take(180)
                    }
                }

                // Wait for the actual result on this background thread, not the UI thread.
                val result: YtDlpResponse = future.get()

                runOnUiThread {
                    running.set(false)
                    downloadButton.isEnabled = true
                    if (result.isSuccess) {
                        progress.progress = 100
                        label.text = "Completed"
                        statusText.text = "Download completed. Check Recent downloads."
                    } else {
                        label.text = "Failed (yt-dlp exit code ${result.exitCode})"
                        statusText.text = "Download failed (exit code ${result.exitCode}). Check the URL or try again."
                    }
                    listExistingDownloads()
                }
            } catch (e: Exception) {
                val cause = e.cause ?: e
                val errorMessage = cause.message ?: cause.javaClass.simpleName
                runOnUiThread {
                    running.set(false)
                    downloadButton.isEnabled = true
                    statusText.text = "Download error: $errorMessage"
                    label.text = "Failed: $errorMessage"
                }
            }
        }.start()
    }

    private fun makeDownloadRow(url: String, quality: String): Pair<ProgressBar, TextView> {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
        }
        val title = TextView(this).apply {
            text = "${if (url.contains("kick.com")) "KICK" else "Rumble"} • $quality\n$url"
            textSize = 13f
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
        }
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        val detail = TextView(this).apply {
            text = "Queued…"
            textSize = 12f
            setPadding(0, 4, 0, 0)
        }
        card.addView(title)
        card.addView(progress)
        card.addView(detail)
        downloadsList.addView(card, 0)
        return Pair(progress, detail)
    }

    private fun listExistingDownloads() {
        val dir = downloadsDir()
        val files = dir.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() } ?: emptyList()
        if (files.isEmpty()) return
        for (file in files.take(20)) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(12, 10, 12, 10)
            }
            row.addView(TextView(this).apply {
                text = file.name
                textSize = 13f
            })
            row.addView(TextView(this).apply {
                text = "${formatBytes(file.length())} • ${android.text.format.DateFormat.format("yyyy-MM-dd HH:mm", file.lastModified())}"
                textSize = 11f
            })
            downloadsList.addView(row)
        }
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return String.format("%.1f KB", kb)
        return String.format("%.1f MB", kb / 1024.0)
    }
}
