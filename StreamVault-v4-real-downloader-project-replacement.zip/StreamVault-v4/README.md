# StreamVault v0.4 — Android downloader project

This revision connects the Download button to the embedded yt-dlp Android library and its real progress callback. It includes a quality selector, URL validation, shared-URL handling, download cards, and a recent-files list.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync and download dependencies.
3. Build > Build APK(s).

Library reference: https://github.com/ffmpegkit-maintained/yt-dlp-android
Dependency pinned to `dev.ffmpegkit-maintained:yt-dlp-android:2.0.2`.

## Storage note
For now downloads are saved in the app-specific external folder `Android/data/com.streamvault/files/StreamVault`. Android manages access to this folder; it is not yet the public `Movies/StreamVault` folder. A later revision can add a user-selected destination using Android's Storage Access Framework.

## Current limitations
- The library's async callback provides progress text; this UI does not yet run downloads in a foreground service, so Android may stop long downloads if the app is backgrounded.
- A download call finishing is not the same as a successful download; error parsing/terminal state handling needs additional testing.
- The free yt-dlp Android library only supports arm64-v8a and x86_64, not 32-bit-only phones.
- Site changes, age/login restrictions, and platform protections can prevent some URLs from downloading.
- Use only for content you are authorized to save. No DRM or access-control circumvention is implemented.
